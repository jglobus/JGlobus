package org.globus.gsi;

public interface SecurityTest {

}
