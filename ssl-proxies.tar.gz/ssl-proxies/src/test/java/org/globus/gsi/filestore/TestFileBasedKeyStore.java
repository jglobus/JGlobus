package org.globus.gsi.filestore;

import org.junit.Ignore;
/**
 * Created by IntelliJ IDEA.
 * User: turtlebender
 * Date: Jan 4, 2010
 * Time: 3:29:11 PM
 * To change this template use File | Settings | File Templates.
 */
@Ignore
public class TestFileBasedKeyStore {


}
